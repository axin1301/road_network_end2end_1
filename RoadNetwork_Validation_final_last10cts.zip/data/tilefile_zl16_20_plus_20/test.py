import glob
import pandas as pd

file_list = glob.glob('./*.csv')

for f in file_list:
    data = pd.read_csv(f)
    if len(data)>100000:
        print(f)
