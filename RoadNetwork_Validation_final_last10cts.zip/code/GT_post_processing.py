# import geopandas as gpd
import pandas as pd
import numpy as np
from shapely.geometry import Point
from PIL import Image
import PIL
PIL.Image.MAX_IMAGE_PIXELS = None
from skimage import morphology,draw
import cv2
import matplotlib.pyplot as plt
import argparse
import os

def GT_post_processing(year, district):

    road = Image.open('../temp_output/'+district+'_GT_primary_'+str(year)+'.png')
    print(np.array(road).shape)

    road_seg = np.array(road)#[30000:40000,30000:40000]
    road_idx = np.where(road_seg > 0)
    # bin_image = np.zeros((road_seg.shape[0],road_seg.shape[1]))
    # bin_image[road_idx[0],road_idx[1]] = 1

    # bin_image = np.uint8(bin_image)
    # test_img = bin_image

    bin_image = np.zeros((road_seg.shape[0],road_seg.shape[1]))
    bin_image[road_idx[0],road_idx[1]] = 1

    image = bin_image

    print(image.shape)
    #实施骨架算法
    skeleton =morphology.skeletonize(image)
    skeleton = Image.fromarray(skeleton)

    if not os.path.exists('../temp_output/topology_construction/'):
        os.makedirs('../temp_output/topology_construction/')

    skeleton.convert('L').save('../temp_output/'+'topology_construction/'+district+'_GT_'+str(year)+'.png')