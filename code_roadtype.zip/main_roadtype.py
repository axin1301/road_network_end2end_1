import os
from test import *
import sys   
from RoadNetwortLable_by_each_road_roadtype import *
from concat_all_label_image_roadtype import *
from GT_post_processing_roadtype import *
from shp2txt_transform_roadtype import *
from mapcompare_roadtype import *

sys.path.append('topology_construction') 
from topology_construction.transform_graph_main_roadtype import *

import glob
import PIL
from PIL import Image
import pandas as pd
import numpy as np
PIL.Image.MAX_IMAGE_PIXELS = None
import datetime

def main():
    print("Hello World")
    #test()
    with open("time_log_roadtype.txt","w") as log_f:
        for year in [2017,2021]:
            for county in ['xixiangxian','shufuxian','guanghexian','danfengxian','jiangzixian','honghexian','liboxian','linquanxian','jingyuxian','lingqiuxian']:
                now_time = datetime.datetime.now()
                log_f.write(county + '   ' +str(year) + '  ' +str(now_time))
                log_f.write('\n')
                print(county, '   ', year)
                RoadNetwortLable_by_each_road_roadtype(year,county)
                now_time = datetime.datetime.now()
                log_f.write(county +  '   ' +str(year) +'  '+'RoadNetwortLable_by_each_road'+ '  '+str(now_time))
                log_f.write('\n')
                concat_all_label_image_roadtype(year,county)
                now_time = datetime.datetime.now()
                log_f.write(county+ '   ' +str(year) +'  '+'concat_all_label_image'+ '  '+str(now_time))
                log_f.write('\n')
                GT_post_processing_roadtype(year,county)
                now_time = datetime.datetime.now()
                log_f.write(county+ '   ' +str(year) + '  '+'GT_post_processing'+ '  '+str(now_time))
                log_f.write('\n')
                # transform_graph_main_roadtype(year,county)
                # now_time = datetime.datetime.now()
                # log_f.write(county+ '   ' +str(year) + '  '+'transform_graph_main'+ '  '+str(now_time))
                # log_f.write('\n')
                # shp2txt_transform_roadtype(year,county)
                # now_time = datetime.datetime.now()
                # log_f.write(county+'   ' +str(year) +'  '+'shp2txt_transform'+ '  '+str(now_time))
                # log_f.write('\n')
                # mapcompare_roadtype('../temp_output/GraphSamplingToolkit-main',county, 'xyx', 'LCR', year)
                # now_time = datetime.datetime.now()
                # log_f.write(county+'   ' +str(year) +'  '+'mapcompare'+ '  '+str(now_time))
                # log_f.write('\n')

                for roadclass in [49,41000,42000,43000,44000,45000,47000,51000,52000,53000,54000]:
                    if not os.path.exists('../temp_output_roadtype/'+county+'_road_label_by_image_'+str(roadclass)+'_'+str(year)):
                        continue
        
                    del_list = os.listdir('../temp_output_roadtype/'+county+'_road_label_by_image_'+str(roadclass)+'_'+str(year)+'/')
                    for f in del_list:
                        file_path = os.path.join('../temp_output_roadtype/'+county+'_road_label_by_image_'+str(roadclass)+'_'+str(year)+'/', f)
                        if os.path.isfile(file_path):
                            os.remove(file_path)

                    if not os.path.exists('../temp_output_roadtype/'+county+'_width3_'+str(roadclass)+'_'+str(year)):
                        continue

                    del_list = os.listdir('../temp_output_roadtype/'+county+'_width3_'+str(roadclass)+'_'+str(year)+'/')
                    for f in del_list:
                        file_path = os.path.join('../temp_output_roadtype/'+county+'_width3_'+str(roadclass)+'_'+str(year)+'/', f)
                        if os.path.isfile(file_path):
                            os.remove(file_path)

                    os.removedirs('../temp_output_roadtype/'+county+'_road_label_by_image_'+str(roadclass)+'_'+str(year))
                    os.removedirs('../temp_output_roadtype/'+county+'_width3_'+str(roadclass)+'_'+str(year))

        # year_list1 = []
        # county_list1 = []
        # positive_pixel_list = []
        # image_weight_list = []
        # image_height_list = []


        # for year in [2017,2021]:
        #     for county in ['shufuxian','xixiangxian','guanghexian','danfengxian','jiangzixian','honghexian','liboxian','linquanxian','jingyuxian','lingqiuxian']:
        #         img = Image.open('../temp_output/'+'topology_construction/'+county+'_GT_'+str(year)+'.png')
        #         img_np = np.array(img)
        #         pos_idx = np.where(img_np>0)
        #         year_list1.append(year)
        #         county_list1.append(county)
        #         positive_pixel_list.append(len(pos_idx[0]))
        #         image_weight_list.append(img_np.shape[0])
        #         image_height_list.append(img_np.shape[1])
        #         now_time = datetime.datetime.now()
        #         log_f.write(county +  '   ' +str(year) +'  '+'GT_statistics'+ '  '+str(now_time))
        #         log_f.write('\n')
        
        # pd_statis = pd.DataFrame({'county':county_list1, 'year':year_list1,'pos_pixel':positive_pixel_list, \
        #                           'img_weight':image_weight_list,'img_height':image_height_list})
        # pd_statis.to_csv('GT_statistics.csv', index=False)

        # df_all = pd.DataFrame({})
        # for year in [2017,2021]:
        #     for county in ['shufuxian','xixiangxian','guanghexian','danfengxian','jiangzixian','honghexian','liboxian','linquanxian','jingyuxian','lingqiuxian']:
        #         df = pd.read_csv('../output/'+county+'_'+str(year)+'.csv')
        #         df_all = pd.concat([df_all, df])
        #         now_time = datetime.datetime.now()
        #         log_f.write(county +  '   ' +str(year) +'  '+'validation_statistics_all'+ '  '+str(now_time))
        #         log_f.write('\n')

        # df_all.to_csv('validation_statistics_all.csv', index=False)





if __name__=="__main__":
    main()