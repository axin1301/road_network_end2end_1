# def test():
#     print(123)

from PIL import Image
import numpy as np
import pandas as pd
import PIL
PIL.Image.MAX_IMAGE_PIXELS = None
# a = '../temp_output/xixiangxian_width3_2021\\xixiangxian_2021_OSM_road_label_y_26414_52368.png'
# print(a)
# print(a.split('.')[-2])


year_list1 = []
county_list1 = []
positive_pixel_list = []
image_weight_list = []
image_height_list = []


for year in [2021]:
    # for county in ['shufuxian','guanghexian','danfengxian','xixiangxian','jiangzixian','honghexian','liboxian','linquanxian','jingyuxian','lingqiuxian']:
    for county in ['xixiangxian']:
        img = Image.open('../temp_output/'+'topology_construction/'+county+'_GT_'+str(year)+'.png')
        img_np = np.array(img)
        pos_idx = np.where(img_np>0)
        year_list1.append(year)
        county_list1.append(county)
        positive_pixel_list.append(len(pos_idx[0]))
        image_weight_list.append(img_np.shape[0])
        image_height_list.append(img_np.shape[1])

pd_statis = pd.DataFrame({'county':county_list1, 'year':year_list1,'pos_pixel':positive_pixel_list, \
                            'img_weight':image_weight_list,'img_height':image_height_list})
pd_statis.to_csv('GT_statistics.csv', index=False)