import os
from test import *
from RoadNetwortLable_by_each_road import *
from concat_all_label_image import *
from GT_post_processing import *
from shp2txt_transform import *
import sys  
sys.path.append('topology_construction') 
from topology_construction.transform_graph_main import *

from mapcompare import *
import glob
import PIL
from PIL import Image
import pandas as pd
import numpy as np
PIL.Image.MAX_IMAGE_PIXELS = None

def main():
    print("Hello World")
    #test()
    for year in [2017,2021]:
        for county in ['shufuxian','guanghexian','danfengxian','xixiangxian','jiangzixian','honghexian','liboxian','linquanxian','jingyuxian','lingqiuxian']:
            RoadNetwortLable_by_each_road(year,county)
            concat_all_label_image(year,county)
            GT_post_processing(year,county)
            transform_graph_main(year,county)
            shp2txt_transform(year,county)
            mapcompare('../temp_output/GraphSamplingToolkit-main',county, 'xyx', 'LCR', year)
    
            del_list = os.listdir('../temp_output/'+county+'_road_label_by_image_'+str(year)+'/')
            for f in del_list:
                file_path = os.path.join('../temp_output/'+county+'_road_label_by_image_'+str(year)+'/', f)
                if os.path.isfile(file_path):
                    os.remove(file_path)

            del_list = os.listdir('../temp_output/'+county+'_width3_'+str(year)+'/')
            for f in del_list:
                file_path = os.path.join('../temp_output/'+county+'_width3_'+str(year)+'/', f)
                if os.path.isfile(file_path):
                    os.remove(file_path)

            os.removedirs('../temp_output/'+county+'_road_label_by_image_'+str(year))
            os.removedirs('../temp_output/'+county+'_width3_'+str(year))

    year_list1 = []
    county_list1 = []
    positive_pixel_list = []
    image_weight_list = []
    image_height_list = []


    for year in [2017,2021]:
        for county in ['shufuxian','guanghexian','danfengxian','xixiangxian','jiangzixian','honghexian','liboxian','linquanxian','jingyuxian','lingqiuxian']:
            img = Image.open('../temp_output/'+'topology_construction/'+county+'_GT_'+str(year)+'.png')
            img_np = np.array(img)
            pos_idx = np.where(img_np>0)
            year_list1.append(year)
            county_list1.append(county)
            positive_pixel_list.append(len(pos_idx[0]))
            image_weight_list.append(img_np.shape[0])
            image_height_list.append(img_np.shape[1])
    
    pd_statis = pd.DataFrame({'county':county_list1, 'year':year_list1,'pos_pixel':positive_pixel_list, \
                              'img_weight':image_weight_list,'img_height':image_height_list})
    pd_statis.to_csv('GT_statistics.csv', index=False)


if __name__=="__main__":
    main()