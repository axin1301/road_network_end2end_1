import os
os.system('construct_node_shp.py')
os.system('cal_dif.py')
os.system('statis.py')